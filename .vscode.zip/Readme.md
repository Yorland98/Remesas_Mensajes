# Remesas y Mensajes LTDA

Sitio web corporativo para empresa de logística y transporte.

## Tecnologías utilizadas
- HTML5
- CSS3
- JavaScript (Vanilla)
- Ionicons

## Instalación local
1. Clona el repositorio
2. Abre `index.html` en tu navegador

## Despliegue
El sitio está desplegado en GitHub Pages